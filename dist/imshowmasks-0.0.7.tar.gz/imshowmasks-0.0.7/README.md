# Imshowmasks
This package makes it easy to handle binary masks and display them with matplotlib's imshow. The central structure is the rgb_mask class, which enables simple operations on the binary masks as well as combining them for display. It is possible to highlight the overlap of masks with different color mixing schemes. 
